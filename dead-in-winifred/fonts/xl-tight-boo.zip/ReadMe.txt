General:

Hello, this is SrXlr11, the most handsome guy in the world!
This font was inspired by Tight Spot BB and Komika Boo, which is why it’s named Tight Boo.
It was a font made in a rush, but with lots of care and love! And I truly hope you like it and make great use of it.


License Information:

XL Tight Boo is a font from XL Fonts, designed by SrXlr11 in 2025. All rights reserved.

XL Tight Boo is FREE for both personal and commercial use.
Any unauthorized monetized redistribution of such is legible to be actioned upon according to the law.
This font is protected by the SIL Open Font License (OFL), read more:
https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL